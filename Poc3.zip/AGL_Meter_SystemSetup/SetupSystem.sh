#!/bin/bash

# get script directory path
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# move to script directory
cd $DIR

# uninstall homescreen and launcher applications
afm-util uninstall homescreen@0.1
afm-util uninstall launcher@0.1

sed -i '2s/.*/shell=ivi-shell.so/' /etc/xdg/weston/weston.ini

sed -i '13s/.*/transform=0/' /etc/xdg/weston/weston.ini

sed -i '27s/.*/mode=off/' /etc/xdg/weston/weston.ini

cp libqtappfw.so.1.0.0 /usr/lib/

# copy conf file to etc
cp serial-port.conf /etc/

afm-util install agl-service-ipc.wgt

afm-util install AGL_Meter.wgt

reboot


