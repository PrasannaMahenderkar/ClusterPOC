# agl-service-ipc


## Pre-requisites

Please follow [this guide](http://docs.automotivelinux.org/docs/devguides/en/dev/reference/host-configuration/docs/1_Prerequisites.html)
to add the AGL-Master repository to your distribution and then install the
cmake module using your distribution package manager.

* **Debian/Ubuntu**

```bash
sudo apt-get install agl-cmake-apps-module-bin
```

* **openSUSE**

```bash
sudo zypper install agl-cmake-apps-module
```

* **Fedora**

```bash
sudo dnf install agl-cmake-apps-module
```

## Set up environement for cross compiling
```bash
source /opt/agl-sdk/6.0.0+snapshot-aarch64/environment-setup-aarch64-agl-linux 
```

## Build  for AGL

```bash
#setup your build environement
. /xdt/sdk/environment-setup-aarch64-agl-linux
#build your application
./conf.d/autobuild/agl/autobuild package
```

## Build for 'native' Linux distros (Fedora, openSUSE, Debian, Ubuntu, ...) using autobuild

```bash
./conf.d/autobuild/linux/autobuild package
```

## Build manually using cmake

```bash
mkdir build && cd build
cmake ..
make 
```
The "ipc-binding.so" will be created in /build/binding/ after successful make.


## setting serial port configuration

1.The IPC service reads serial port configuration used for service from file “serial-port.conf”
2.Create the file serial-port.conf at /etc and add the below line,
setport=/dev/ttyXXX  (e.g. for ttyUSB0 /dev/ttyUSB0)



## Steps to Meter Application with IPC service on board

```bash 
cd /home/ipc_service
./AGL_Meter
```