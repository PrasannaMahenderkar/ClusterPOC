////////////////////////////////////////////////////////////////////////////////
// NAME:  ipc-binding.c
// DESCRIPTION:  AGL ipc binding to handle RH850 communication
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <json-c/json.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <systemd/sd-event.h>
#include <stdbool.h>
#define AFB_BINDING_VERSION 2
#define START_FRAME_DATA 0x5A5A5A5A
#define FRAME_START_DATA_SIZE 4
#define FRAME_SIZE_AFTER_START_DATA 33
#define FRAME_TYPE_0 0x00
#include <afb/afb-binding.h>

static int fd; /* File descriptor for serial port */
static int count = 0;
static struct termios SerialPortSettingsNew; /* termios structure for serial port configuration */
static char port_name[15];
static bool isFirstSubscribe = true;
static bool isNewData = true;

/**
* @brief read serial port configuration from file "/etc/serial-port.conf" 
* @return void
*/
static void read_conf()
{
	char *port = NULL;
	FILE *fptr = NULL;
	char file_read[20];
	memset(port_name, '\0', sizeof(port_name));
	memset(file_read, '\0', sizeof(file_read));
	if ((fptr = fopen("/etc/serial-port.conf", "r")) == NULL)
	{
		AFB_NOTICE("Error opening configuration file /etc/serial-port.conf");
		return;
	}
	fscanf(fptr, "%[^\n]", file_read);
	port = strchr(file_read, '/');
	size_t len = strlen(port);
	strncpy(port_name, port, len + 1);
	AFB_NOTICE("Serial Port configuration:\"%s\"", port_name);
	fclose(fptr);
}

struct event
{
	struct event *next;
	afb_event event;
	char name[];
};

static struct event *events = NULL;

/**
* @brief Helper function that searches for a specific event
* @param event name 
* @return struct* : event structure pointer
*/
static struct event *event_get(const char *name)
{
	struct event *e = events;
	while (e && strcmp(e->name, name))
		e = e->next;
	return e;
}

/**
* @brief get event by afb_event
* @param afb_event
* @return struct* : event structure pointer
*/
static struct event *event_get_event(const struct afb_event *event)
{
	struct event *e = events;
	while (e && (&e->event != event))
	{
		e = e->next;
	}
	return e;
}

/**
* @brief send event to subscribers
* @param json_object to push as event
* @param event name 
* @return int : subscribers count
*/
static int do_event_push(struct json_object *args, const char *name)
{
	struct event *e;
	e = event_get(name);
	return e ? afb_event_push(e->event, json_object_get(args)) : -1;
}

/**
* @brief add event to sd event loop
* @param event name 
* @return int : 0 for success & -1 for failure  
*/
static int event_add(const char *name)
{
	struct event *e;

	/* check valid name */
	e = event_get(name);
	if (e)
		return -1;

	/* creation */
	e = malloc(strlen(name) + sizeof *e + 1);
	if (!e)
		return -1;
	strcpy(e->name, name);

	/* make the event */
	e->event = afb_daemon_make_event(name);
	if (!e->event.closure)
	{
		free(e);
		return -1;
	}

	/* link */
	e->next = events;
	events = e;
	return 0;
}

/**
* @brief subscribe to event of "name" 
* @param request from application
* @param event name
* @return int : 0 for success & -1 for failure  
*/
static int event_subscribe(struct afb_req request, const char *name)
{
	struct event *e;
	e = event_get(name);
	return e ? afb_req_subscribe(request, e->event) : -1;
}

/**
* @brief unsubscribe to event of "name" 
* @param request from application
* @param event name
* @return int : 0 for success & -1 for failure  
*/
static int event_unsubscribe(struct afb_req request, const char *name)
{
	struct event *e;
	e = event_get(name);
	return e ? afb_req_unsubscribe(request, e->event) : -1;
}

/**
* @brief delete the event 
* @param request from application
* @param event name
* @return int : 0 for success & -1 for failure  
*/
static int event_del(const struct afb_event *event)
{
	struct event *e, **p;

	/* check exists */
	e = event_get_event(event);
	if (!e)
		return -1;

	/* unlink */
	p = &events;
	while (*p != e)
		p = &(*p)->next;
	*p = e->next;

	/* destroys */
	afb_event_unref(e->event);
	free(e);
	return 0;
}

/**
* @brief create json response and push event
* @param array containing data frame 
* @param event name
* @return void 
*/
static void create_json_resp(unsigned char arr[], const char *event_name)
{
	int i;
	struct json_object *jobj = NULL;
	jobj = json_object_new_object();
	struct json_object *jarr = json_object_new_array();
	for (i = 0; i < FRAME_SIZE_AFTER_START_DATA; i++)
	{
		json_object_array_add(jarr, json_object_new_int(arr[i]));
	}
	json_object_object_add(jobj, "frame_data", jarr);
	do_event_push(jobj, event_name);
}

/**
* @brief callback function to send events
* @param sd event source 
* @param file descriptor
* @param revents
* @param userdata
* @return int 
*/
static int read_data_push(sd_event_source *src, int fd, uint32_t revents, void *userdata)
{
	int start_frame=0;
	unsigned char start_frame_byte=0;
	unsigned char frame_till_EOF[FRAME_SIZE_AFTER_START_DATA];
	memset(frame_till_EOF, '\0', sizeof(frame_till_EOF));
	

	if (isNewData)
	{
		read(fd, &start_frame_byte, 1);
		AFB_NOTICE("---frame start byte---:>%02x", start_frame_byte);
		if (start_frame_byte == 0x5a)
		{
			count++;
			AFB_NOTICE("---frame start byte count---:>%d", count);
		}
		else
		{
			count = 0;
		}
		if (count == FRAME_START_DATA_SIZE)
		{
			read(fd, &frame_till_EOF, FRAME_SIZE_AFTER_START_DATA);
			if (frame_till_EOF[1] == FRAME_TYPE_0) /* check for frame type FT=0 */
			{
				AFB_NOTICE("--frame type is FT0---\n");
				create_json_resp(frame_till_EOF, "FT0");
				isNewData = false;
			}
		}
	}
	else
	{
		read(fd, &start_frame, FRAME_START_DATA_SIZE);
		if (start_frame == START_FRAME_DATA)
		{
			read(fd, &frame_till_EOF, FRAME_SIZE_AFTER_START_DATA);
			if (frame_till_EOF[1] == FRAME_TYPE_0) /* check for frame type FT=0 */
			{
				AFB_NOTICE("--frame type is FT0---\n");
				create_json_resp(frame_till_EOF, "FT0");
			}
		}
	}
	return 0;
}

/**
* @brief subscribe to frame_type event
* @param request from application
* @return void
*/
static void subscribe(struct afb_req request)
{
	struct termios SerialPortSettingsOld;
	event_add("FT0"); /*create event of frametype FT0*/
	const char *name = afb_req_value(request, "frame_type");
	if (!name || !event_get(name)) /* check if event name is valid */
	{
		afb_req_fail(request, "failed", "event doesn't exist");
		return;
	}
	fd = open(port_name, O_RDONLY | O_NOCTTY);
	if (fd == -1) /* Error Checking */
	{
		afb_req_fail(request, "ERROR", "error opening serial port");
		return;
	}
	AFB_NOTICE("\"%s\" opened successfully", port_name);
	if (0 != event_subscribe(request, name))
	{
		afb_req_fail(request, "failed", "subscription error");
		return;
	}
	afb_req_success(request, NULL, "subscription success");
	tcgetattr(fd, &SerialPortSettingsOld); /* Get the current attributes of the Serial port */
	int setval = tcsetattr(fd, TCSANOW, &SerialPortSettingsNew);
	if (setval != 0)
	{
		AFB_NOTICE("ERROR in Setting attributes to serial port"); /* Set the new attributes to the termios structure */
	}
	sd_event_source *source = NULL;
	if (isFirstSubscribe == true)
	{
		tcflush(fd, TCIFLUSH); /* Discard old data in the rx buffer */
		isFirstSubscribe = false;
	}
	sd_event_add_io(afb_daemon_get_event_loop(), &source, fd, EPOLLIN, read_data_push, NULL);
}

/**
* @brief unsubscribe to frame_type event
* @param request from application
* @return void
*/
static void unsubscribe(struct afb_req request)
{
	const char *name = afb_req_value(request, "frame_type");
	if (name == NULL)
	{
		afb_req_fail(request, "failed", "bad arguments");
	}
	else if (0 != event_unsubscribe(request, name))
	{
		afb_req_fail(request, "failed", "unsubscription error");
	}
	else
	{
		afb_req_success(request, NULL, "unsubscription success");
		struct event *e = NULL;
		e = event_get("FT0");
		event_del(&e->event);
		isNewData = true;
		count = 0;
		close(fd);
	}
}

static const struct afb_verb_v2 verbs[] = {
	{.verb = "subscribe", .session = AFB_SESSION_NONE, .callback = subscribe},

	{.verb = "unsubscribe", .session = AFB_SESSION_NONE, .callback = unsubscribe},
	{NULL}};
	
/**
* @brief binding initialization function for configuring serial port
* @return int
*/
static int initserial()
{
	read_conf(); /*read serial port configuration from file*/

	/* Setting the Baud rate */
	cfsetispeed(&SerialPortSettingsNew, B115200); /* Set Read  Speed as 115200                       */
	
	/* 8N1 Mode */
	SerialPortSettingsNew.c_cflag &= ~PARENB; 
	SerialPortSettingsNew.c_cflag &= ~CSTOPB; 
	SerialPortSettingsNew.c_cflag &= ~CSIZE;  
	SerialPortSettingsNew.c_cflag |= CS8;	 

	SerialPortSettingsNew.c_cflag &= ~CRTSCTS;		
	SerialPortSettingsNew.c_cflag |= CREAD | CLOCAL; 

	SerialPortSettingsNew.c_iflag &= ~(IXON | IXOFF | IXANY);		  
	SerialPortSettingsNew.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG);

	SerialPortSettingsNew.c_oflag &= ~OPOST; 

	/* Setting Time outs */
	SerialPortSettingsNew.c_cc[VMIN] = 0;  
	SerialPortSettingsNew.c_cc[VTIME] = 0; 
	return 0;
}

const struct afb_binding_v2 afbBindingV2 = {
	.info = "IPC Service",
	.api = "ipc",
	.specification = NULL,
	.verbs = verbs,
	.preinit = NULL,
	.init = initserial,
	.onevent = NULL,
	.noconcurrency = 0};
