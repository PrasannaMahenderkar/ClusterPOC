////////////////////////////////////////////////////////////////////////////////
// NAME:  MeterUtils.h
// DESCRIPTION:  This file lists all enum values required to display on HMI.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef METERUTILS_H
#define METERUTILS_H

enum FUEL_STATUS
{
	INVALID = 0,
	VALID
};

enum DISTANCE_UNIT
{
	KM = 0,
	MILE
};

enum FUEL_UNIT
{
	KM_PER_LTR = 0,
	LTR_PER_100KM,
	MILES_PER_GALLON
};

#endif //METERUTILS_H
