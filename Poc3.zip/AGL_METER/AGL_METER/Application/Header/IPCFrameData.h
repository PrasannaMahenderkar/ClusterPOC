////////////////////////////////////////////////////////////////////////////////
// NAME:  IPCFrameData.h
// DESCRIPTION:  This class handles parsing of data frame.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef IPCFRAMEDATA_H
#define IPCFRAMEDATA_H

#include "Logger.h"

using namespace std;

class IPCFrameData
{
    unsigned short m_analogVehicleSpeed;
    unsigned short m_avgFuel;
    bool m_avgFuelStatus;
    UINT8 m_avgFuelUnit;
    unsigned short m_digitalVehicleSpeed;
    bool m_distanceUnit;
    UINT8 m_guageWaterTemp;
    unsigned short m_instantFuel;
    UINT8 m_instantFuelUnit;
    unsigned int m_ODO;
    int m_periodicNotification;
    unsigned short m_rpm;
    UINT8 m_segmentWaterTemp;
    unsigned int m_trip;

public:

    /**
     * @brief Constructor
     */
    IPCFrameData();
    IPCFrameData(const unsigned char* data,const size_t size);
	
	/**
     * @brief Destructor
     */
    ~IPCFrameData();
	
	/**
     * @brief getter for digital vehicle speed
     * @return unsigned short : digital vehicle speed
     */
    unsigned short getDigitalVehicleSpeed() const;
	
	/**
     * @brief getter for analog vehicle speed
     * @return unsigned short : analog vehicle speed
     */
    unsigned short getAnalogVehicleSpeed() const;
	
	/**
     * @brief getter for average fuel value.
     * @return unsigned short : average fuel value
     */
    unsigned short getAvgFuel() const;
	
	/**
     * @brief getter for average fuel status.
     * @return bool : average fuel status
     */
    bool getAvgFuelStatus() const;
	
	/**
     * @brief getter for average fuel unit.
     * @return UINT8 : average fuel unit
     */
    UINT8 getAvgFuelUnit() const;
	
	/**
     * @brief getter for instant fuel unit.
     * @return UINT8 : instant fuel unit
     */
    UINT8 getInstantFuelUnit() const;
	
	/**
     * @brief getter for distant unit.
     * @return string : distant unit
     */
    string getDistanceUnit()const ;
	
	/**
     * @brief getter for distant unit in enum form.
     * @return string : distant unit
     */
    string getPerDistanceUnit() const;
	
	/**
     * @brief getter for unit in enum form.
	 * @param unit data value
     * @return string : unit
     */
    string getUnit(UINT8 unitData) const;
	
	/**
     * @brief getter for Gauge water temperature.
     * @return UINT8 : Gauge water temperature
     */
    UINT8 getGaugeWaterTemperature() const;
	
	/**
     * @brief getter for instant fuel.
     * @return unsigned short : instant fuel
     */
    unsigned short getInstantFuel() const;
	
	/**
     * @brief getter for odometer.
     * @return unsigned int : odometer
     */
    unsigned int getODO() const;
	
	/**
     * @brief getter for rpm.
     * @return unsigned short : rpm
     */
    unsigned short getRpm() const;
	
	/**
     * @brief getter for segment water temperature.
     * @return UINT8 : segment water temperature.
     */
    UINT8 getSegmentWaterTemperature() const;
	
	/**
     * @brief getter for trip.
     * @return unsigned int : trip
     */
    unsigned int getTrip() const;	
		
	/**
     * @brief convert little endian data to big endian format for four byte.
	 * @param int : little endian data
     * @return int : big endian data
     */
    int litToBigEndianFourByte(int);
	
	/**
     * @brief convert little endian data to big endian format for two byte.
	 * @param unsigned short : little endian data
     * @return unsigned short : big endian data
     */
    unsigned short litToBigEndianTwoByte(unsigned short);
	
	/**
     * @brief convert arary data into integer format.
	 * @param unsigned char* : data array
	 * @param  int : size in bytes
	 * @param  int : start index
     * @return int : integer data
     */
    int getIntData(const unsigned char* data,int, int) const;

    /**
     * @brief to populate data into member variables
     * @param unsigned char* : data frame
     */

    void populateIPCFrameData(const unsigned char*);
	
	/**
     * @brief print logs in file for debugging purpose
	 * @param unsigned char* : data frame
     * @param size_t : size of frame
     */
    void printFrameData(const unsigned char* , const size_t ) const;

};
#endif
