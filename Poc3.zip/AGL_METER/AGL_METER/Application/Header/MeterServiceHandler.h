////////////////////////////////////////////////////////////////////////////////
// NAME:  MeterServiceHandler.h
// DESCRIPTION:  This class handles data receievd from websocket.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef METERSERVICEHANDLER_H
#define METERSERVICEHANDLER_H

#include <QJsonObject>
#include <QJsonArray>
#include <QObject>
#include "Meter.h"
#include "Logger.h"

class MeterServiceHandler : public QObject
{

    Q_OBJECT
public:
	/**
     * @brief Constructor
     */
    explicit MeterServiceHandler(QObject *parent = nullptr,int port =8020, QString secret="HELLO");
	
	/**
     * @brief Destructor
     */
    virtual ~MeterServiceHandler();
	
	/**
     * @brief disconnect connection with Meter class and deallocate memory
     */
    void cleanup();
	
	/**
     * @brief form connection with Meter class and deallocate memory
     */
    void init(int& port, QString& secret);

signals:
	/**
     * @brief emit signal with data fram when data recievd from service
	 * @param QJsonObject: data frame
     */
    void IPCDataFrameRecvEventSIG(const QJsonObject& data);

public slots:
	/**
     * @brief Check data recievd from service and emit using IPCDataFrameRecvEventSIG
	 * @param QJsonObject: data frame
     */
    void IPCDataFrameRecvEventSLOT(const QJsonObject& data);

private:
    Meter* m_MeterObj;
    static UINT8 m_PrevCmdCounter;
    static bool m_IsFirstCall;
};
#endif
