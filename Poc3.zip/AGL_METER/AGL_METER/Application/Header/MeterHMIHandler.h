////////////////////////////////////////////////////////////////////////////////
// NAME:  MeterHMIHandler.h
// DESCRIPTION: This class maintain and update data on Meter HMI
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef METERHMIHANDLER_H
#define METERHMIHANDLER_H

#include <QObject>
#include <QQmlContext>
#include "MeterServiceHandler.h"

class MeterHMIHandler : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QJsonObject screendata READ screendata WRITE setScreendata NOTIFY screendataChanged)
    void updateHMIScreen(const UINT8* data);
public:
	/**
     * @brief Constructor
     */
    explicit MeterHMIHandler(QObject *parent = nullptr,QQmlContext* context = nullptr,int port = 8020, QString secret = "HELLO");
    virtual ~MeterHMIHandler();
	
	/**
     * @brief disconnect connection with MediaServicehandler and deallocate memory
     */
    void cleanup();
	
	/**
     * @brief create connection with MediaServicehandler.
     */
    void init();

	/**
     * @brief getter for screendata object.
	 * @return QJsonObject : screendata
     */
    QJsonObject screendata(){return m_screenData;}
	
	/**
     * @brief setter for screendata object.
	 * @return QJsonObject : data to be set
     */
    void setScreendata(QJsonObject data);

signals:
	/**
     * @brief singnal to send data to HMI
	 * @param QJsonObject : data to be send to HMI
     */
    void screendataChanged(const QJsonObject& data);
	
public slots:
	/**
     * @brief process frame data into unsigned char array format
	 * @param QJsonObject : frame data
     */
    void processIPCDataFrameRecvEventSLOT(const QJsonObject& jsonFrame);
private:

    QQmlContext* m_Context;
    MeterServiceHandler* m_MeterServiceHandlerObj;
    QJsonObject m_screenData;
};

#endif // METERHMIHANDLER_H
