////////////////////////////////////////////////////////////////////////////////
// NAME:  Logger.h
// DESCRIPTION:  This file handles all logging mechanism required for debugging.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef LOGGER_H
#define LOGGER_H

#include <fstream>
#include <sstream>
#include <QDebug> // To be enabled when enabling below qDebug() logging macros

using namespace std;
typedef unsigned char UINT8;
#define CHECK_POINTER_FOR_NULL(obj) {if(obj == nullptr) return;}


//Below Logging can be done in QT Application and file as well. Only one type of logging can be enabled at a time.

#ifdef _ETL_DEBUG_
//Copy logs into file.
#define LOG(msg) {std::ostringstream _s; _s << msg; Logger::debug_printer("LOG", __FILE__, __LINE__ , _s.str());}
#define LOG_ERROR(msg) {std::ostringstream _s; _s << msg; Logger::debug_printer("ERROR", __FILE__, __LINE__ , _s.str());}

//The below lines can be enabled to print logs on Application output of QT.
//#define LOG(msg) {qDebug()<<__DATE__<<"  "<<__TIME__<<"LOG: "<<__FILE__<< " ("<<__LINE__ <<") : "<<msg;}
//#define LOG_ERROR(msg) {qDebug()<<__DATE__<<"  "<<__TIME__<<"ERROR"<<__FILE__<< " ("<<__LINE__ <<") : "<<msg;}
#else
#define LOG(msg) 0
#define LOG_ERROR(msg) 0
#endif

class Logger
{
public:
    Logger();
    static void debug_printer(string type, string fn, int line, string msg);
};







#endif // LOGGER_H
