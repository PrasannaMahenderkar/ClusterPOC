////////////////////////////////////////////////////////////////////////////////
// NAME:  IPCMessageParser.h
// DESCRIPTION:  This class handles parsing of frame data received from middleware.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef IPCMESSAGEPARSER_H
#define IPCMESSAGEPARSER_H

#include "IPCFrameData.h"

class IPCMessageParser
{
    UINT8 m_blockChckCharacter;
    UINT8 m_commandCounter;
    UINT8 m_dataLength;
    UINT8 m_frameType;
    UINT8 m_splitIndex;
    IPCFrameData m_objIPCFrameData;

public:
	/**
     * @brief Constructor
     */
    IPCMessageParser(const UINT8* data);
	
	/**
     * @brief Destructor
     */
    ~IPCMessageParser();
	
	/**
     * @brief getter for data frame type.
     * @return UINT8 : type of frame
     */
    UINT8 getframeType() const;
	
	/**
     * @brief getter for IPCFrameData poiner.
     * @return IPCFrameData& : pointer for IPCFrameData
     */
    IPCFrameData& getIPCFrameDataObj();
	
	/**
     * @brief print logs in file for debugging purpose
	 * @param unsigned char* : data frame
     */
    void printData(const UINT8*) const;

};
#endif
