#include <QtCore/QUrlQuery>
#include "MeterServiceHandler.h"

UINT8 MeterServiceHandler :: m_PrevCmdCounter = 0;
bool MeterServiceHandler :: m_IsFirstCall = true;

MeterServiceHandler::MeterServiceHandler(QObject *parent,int port, QString secret) : QObject(parent)
{
    LOG("MeterServiceHandler() called");
    try{
        init(port,secret);
    }catch(const char* msg)
    {
        LOG(msg);
    }
}

MeterServiceHandler::~MeterServiceHandler()
{
    cleanup();
}

void MeterServiceHandler::init(int& port, QString& secret)
{
    LOG("init() called, port = "<<port<<"secret = "<<secret.toStdString());
    QUrl bindingAddress;
    bindingAddress.setScheme(QStringLiteral("ws"));
    bindingAddress.setHost(QStringLiteral("127.0.0.1"));
    bindingAddress.setPort(port);
    bindingAddress.setPath(QStringLiteral("/api"));
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("token"), secret);
    bindingAddress.setQuery(query);
    // create Meter Object
    if(m_MeterObj == nullptr)
        m_MeterObj = new Meter(bindingAddress);

    if(m_MeterObj == nullptr)
        throw "Meter Object not created with given binding port/token";

    // Connections for IPC Data events
    QObject::connect(m_MeterObj, SIGNAL(IPCdataFrameReceived(const QJsonObject&)), this, SLOT(IPCDataFrameRecvEventSLOT(const QJsonObject&)),Qt::UniqueConnection);
}


void MeterServiceHandler::IPCDataFrameRecvEventSLOT(const QJsonObject& jresp)
{
    LOG("IPCDataFrameRecvEventSLOT() called");
    if(jresp.isEmpty())
    {
        LOG_ERROR("Json Frame received from IPC Service is Empty");
        return;
    }
    //LOG("jresp : "<<jresp);
    QJsonObject prevJson =jresp;
    QJsonArray data_array=prevJson["frame_data"].toArray();
    UINT8 cmdCounter = (UINT8)data_array[0].toInt();
    LOG("command counter : ==============================="<<cmdCounter);

    if(m_IsFirstCall==true)
    {
        m_PrevCmdCounter = cmdCounter;
        emit IPCDataFrameRecvEventSIG(jresp);
        m_IsFirstCall=false;
        return;
    }

    if(++m_PrevCmdCounter == cmdCounter)
    {
        m_PrevCmdCounter = cmdCounter;
        emit IPCDataFrameRecvEventSIG(jresp);
    }
}

void MeterServiceHandler::cleanup()
{
    disconnect(m_MeterObj);
    if(m_MeterObj != nullptr)
    {
        delete m_MeterObj;
        m_MeterObj = nullptr;
    }
}
