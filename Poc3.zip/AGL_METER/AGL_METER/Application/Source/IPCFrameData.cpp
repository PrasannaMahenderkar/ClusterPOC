#include <string.h>
#include "IPCFrameData.h"
#include "MeterUtils.h"

IPCFrameData::IPCFrameData()
{
    m_periodicNotification = 0;
    m_analogVehicleSpeed = 0;
    m_rpm = 0;
    m_ODO = 0;
    m_trip = 0;
    m_digitalVehicleSpeed = 0;
    m_distanceUnit = 0;
    m_guageWaterTemp = 0;
    m_segmentWaterTemp = 0;
    m_avgFuelUnit = 0;
    m_avgFuel = 0;
    m_avgFuelStatus = 0;
    m_instantFuelUnit = 0;
    m_instantFuel = 0;
}


IPCFrameData :: IPCFrameData(const UINT8* data,const size_t dataSize)
{
    LOG("IPCFrameData() called");
    CHECK_POINTER_FOR_NULL(data);
    populateIPCFrameData(data);
	//printing the IPC Frame Received
    printFrameData(data, dataSize);
}

IPCFrameData :: ~IPCFrameData()
{
    
}

void IPCFrameData::populateIPCFrameData(const unsigned char* data)
{
    LOG("populateIPCFrameData() called");
    //Reading the IPC Frame data into member variables
    m_periodicNotification = litToBigEndianFourByte(getIntData(data,4, 4));
    m_analogVehicleSpeed = (litToBigEndianTwoByte(getIntData(data, 2, 8)));
    m_rpm = litToBigEndianTwoByte(getIntData(data, 2, 10));
    m_ODO = litToBigEndianFourByte(getIntData(data,4, 12));

    m_trip = (litToBigEndianFourByte(getIntData(data,4, 16)));
    m_digitalVehicleSpeed = (litToBigEndianTwoByte(getIntData(data,2, 20)));

    m_distanceUnit = data[22];
    m_guageWaterTemp = data[23];
    m_segmentWaterTemp = data[24];
    m_avgFuelUnit = data[25];

    m_avgFuel = (litToBigEndianTwoByte(getIntData(data,2, 26)));
    m_avgFuelStatus = data[28];
    m_instantFuelUnit = data[29];
    m_instantFuel = (litToBigEndianTwoByte(getIntData(data,2,30)));
}

//function to convert 4 byte little endian data to big Endian 
int IPCFrameData :: litToBigEndianFourByte(int data)
{
    int bigdata = (((data>>24) & 0x000000ff) | ((data>>8) & 0x0000ff00) | ((data<<8) & 0x00ff0000) | ((data<<24) & 0xff000000));
    LOG("litToBigEndianFourByte :"<<bigdata);
    return bigdata;
}
//function to convert 2 byte little endian data to big Endian 
unsigned short IPCFrameData :: litToBigEndianTwoByte(unsigned short data)
{
    unsigned short bigdata = (((data >> 8)&0x00FF)  | ((data << 8)& 0xFF00));
    LOG("litToBigEndianTwoByte :"<<bigdata);
    return bigdata ;
}

//Function to extract the required bytes from whole IPC Data
int IPCFrameData :: getIntData(const UINT8* IPCData,int byteSize, int start) const
{  
    if(IPCData == nullptr)
        return -1;

    int dataValue = 0;
    if(4 == byteSize)
    {

        dataValue = ((((IPCData[start] << 24)| IPCData[start+1]<<16)| IPCData[start+2]<<8) |IPCData[start+3]);
    }
    else if (2 == byteSize)
    {
        dataValue = IPCData[start] << 8 | IPCData[start + 1];
    }
    return dataValue;
}

unsigned short IPCFrameData :: getDigitalVehicleSpeed() const
{
    return m_digitalVehicleSpeed;
}

unsigned short IPCFrameData :: getAnalogVehicleSpeed() const
{
    return m_analogVehicleSpeed;
}

unsigned short IPCFrameData :: getAvgFuel() const
{
    return m_avgFuel;
}

bool IPCFrameData :: getAvgFuelStatus() const
{
    return m_avgFuelStatus;
}

UINT8 IPCFrameData :: getAvgFuelUnit() const
{
    return m_avgFuelUnit;
}

string IPCFrameData::getUnit(UINT8 unitData) const
{
    LOG("IPCFrameData::getUnit()"<<unitData);
    string unit;
    switch(unitData)
    {
    case FUEL_UNIT::KM_PER_LTR:
        unit ="km/l";
        break;
    case FUEL_UNIT::LTR_PER_100KM:
        unit ="l/100km";
        break;
    case FUEL_UNIT::MILES_PER_GALLON:
        unit = "mpg";
        break;
    default:
        unit ="";
        break;
    }
    return unit;
}

UINT8 IPCFrameData :: getInstantFuelUnit() const
{
    return m_instantFuelUnit;
}


//will be called for speed parameter unit
string IPCFrameData :: getPerDistanceUnit() const
{
    LOG("getPerDistanceUnit()"<<m_distanceUnit);
    if (m_distanceUnit == DISTANCE_UNIT::MILE)
    {
        return "mph";
    }
    else
        return "km/hr";
}

// will be called for updating units for trip,fuel and ODO
string IPCFrameData :: getDistanceUnit() const
{
    LOG("getPerDistanceUnit()"<<m_distanceUnit);
    if (m_distanceUnit == DISTANCE_UNIT::MILE)
    {
        return "miles";
    }
    else
        return "km";
}

UINT8 IPCFrameData :: getGaugeWaterTemperature() const
{
    return m_guageWaterTemp;
}

unsigned short IPCFrameData :: getInstantFuel() const
{
    return m_instantFuel;
}

unsigned int IPCFrameData :: getODO() const
{
    return m_ODO;
}

unsigned short IPCFrameData :: getRpm() const
{
    return m_rpm;
}

UINT8 IPCFrameData :: getSegmentWaterTemperature() const
{
    return m_segmentWaterTemp;
}

unsigned int IPCFrameData :: getTrip() const
{
    return m_trip;
}

//prints data, commented argument to eliminate warning.
void IPCFrameData :: printFrameData(const UINT8* /*data*/, const size_t /*size*/) const
{
    LOG("IPCFrameData : printFrameData starts");

    //for (int i=0; i < 37; i++)
    //LOG("DataFrame "<<(int)data[i]);

    LOG("m_periodicNotification : " <<m_periodicNotification);
    LOG("m_analogVehicleSpeed   : " <<m_analogVehicleSpeed);
    LOG("m_rpm                  : " <<m_rpm);
    LOG("m_ODO  		        : " <<m_ODO);
    LOG("m_trip                 : " <<m_trip);
    LOG("m_digitalVehicleSpeed  : " <<m_digitalVehicleSpeed);
    LOG("m_distanceUnit         : " <<m_distanceUnit);
    LOG("m_guageWaterTemp       : " <<(int)m_guageWaterTemp);
    LOG("m_segmentWaterTemp     : " <<(int)m_segmentWaterTemp);
    LOG("m_avgFuelUnit          : " <<m_avgFuelUnit);
    LOG("m_avgFuel              : " <<m_avgFuel);
    LOG("m_avgFuelStatus        : " <<m_avgFuelStatus);
    LOG("m_instantFuelUnit      : " <<(int)m_instantFuelUnit);
    LOG("m_instantFuel          : " <<m_instantFuel);

}
