#include <Logger.h>
#include <QJsonDocument>
#include "MeterHMIHandler.h"
#include "IPCMessageParser.h"


MeterHMIHandler::MeterHMIHandler(QObject *parent,QQmlContext *context,int port, QString secret) : QObject(parent),m_Context(context)
{
    if(m_MeterServiceHandlerObj == nullptr)
        m_MeterServiceHandlerObj = new MeterServiceHandler(parent,port,secret);

    if(m_Context)
        m_Context->setContextProperty("MeterHMIHandler",this);
     init();
}


MeterHMIHandler::~MeterHMIHandler()
{
    cleanup();
}

void MeterHMIHandler::cleanup()
{
    QObject::disconnect(m_MeterServiceHandlerObj);
    if(m_MeterServiceHandlerObj != nullptr)
    {
        delete m_MeterServiceHandlerObj;
        m_MeterServiceHandlerObj = nullptr;
    }
}

void MeterHMIHandler::init()
{
    LOG("init() called");
    CHECK_POINTER_FOR_NULL(m_MeterServiceHandlerObj);
    QObject::connect(m_MeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(const QJsonObject&)), this, SLOT(processIPCDataFrameRecvEventSLOT(const QJsonObject&)),Qt::UniqueConnection);
}


void MeterHMIHandler::processIPCDataFrameRecvEventSLOT(const QJsonObject& jsonFrame)
{
    if(jsonFrame.isEmpty())
    {
        LOG_ERROR("Json Frame received from IPC Service is Empty");
        return;
    }
    LOG("processIPCDataFrameRecvEventSLOT() called");
    //QJsonDocument jsonDoc(jsonFrame);

    //LOG("JsonFrame -------------------"<<jsonDoc.object());
    //QJsonArray data_array = jsonFrame.value("frame_data").toArray();
    QJsonArray data_array=jsonFrame["frame_data"].toArray();
    if(data_array.isEmpty())
    {
        LOG_ERROR("Data array received from IPC Service is Empty");
        return;
    }
    //LOG("JSON array extracted from IPC Frame: "<<data_array);
    size_t size = data_array.size();
    UINT8 IPCData[size];
    int arrayIndex = 0;
    foreach (const QJsonValue & jsonIndex, data_array)
    {
        IPCData[arrayIndex] = (UINT8)jsonIndex.toInt();
        //LOG("IPCData[j]: "<<IPCData[j]);
        arrayIndex++;
    }
    updateHMIScreen(IPCData);
}

void MeterHMIHandler::updateHMIScreen(const UINT8 *data)
{
    LOG("MeterHMIHandler::updateHMIScreen() called ");
    CHECK_POINTER_FOR_NULL(data);
    IPCMessageParser IPCMsgObj(data);
    IPCFrameData& IPCFrameObj = IPCMsgObj.getIPCFrameDataObj();

    m_screenData.insert("speed",IPCFrameObj.getAnalogVehicleSpeed());
    QString perdistanceUnit = QString::fromStdString(IPCFrameObj.getPerDistanceUnit());
    m_screenData.insert("SpeedUnit",perdistanceUnit);
    m_screenData.insert("AverageFuel",IPCFrameObj.getAvgFuel());
    QString avgfuelunit = QString::fromStdString(IPCFrameObj.getUnit(IPCFrameObj.getAvgFuelUnit()));
    m_screenData.insert("AverageFuelUnit",avgfuelunit);
    m_screenData.insert("InstantFuel",IPCFrameObj.getInstantFuel());
    QString instantfuelunit = QString::fromStdString(IPCFrameObj.getUnit(IPCFrameObj.getInstantFuelUnit()));
    m_screenData.insert("InstantFuelUnit",instantfuelunit);
    m_screenData.insert("GaugeWaterTemp",IPCFrameObj.getGaugeWaterTemperature());
    m_screenData.insert("OdoValue",(int)IPCFrameObj.getODO());
    m_screenData.insert("TripValue",(int)IPCFrameObj.getTrip());
    //m_screenData.insert("Rpm",IPCFrameObj.getRpm());
    QString distanceUnit = QString::fromStdString(IPCFrameObj.getDistanceUnit());
    m_screenData.insert("OdoUnit",distanceUnit);
    m_screenData.insert("TripUnit",distanceUnit);

    QJsonDocument doc(m_screenData);

    //LOG("Inserted array in json object :"<<doc.toJson());
    emit screendataChanged(m_screenData);

}


void MeterHMIHandler::setScreendata(QJsonObject data)
{
    m_screenData = data;
}


