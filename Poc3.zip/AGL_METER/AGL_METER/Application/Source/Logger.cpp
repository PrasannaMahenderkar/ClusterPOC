#include "Logger.h"
Logger::Logger()
{

}

void Logger::debug_printer(string type, string fn, int line, string msg) {

    std::ofstream log_file("/home/ipc_service/MeterLogFile.txt", std::ios_base::out | std::ios_base::app );
    log_file << __TIME__<<": "<<type << ": "<< fn << "(" << line << "): ";
    if (msg.size()) {
        log_file << "\t" << msg;
    }
    log_file << std::endl;
    long size = log_file.tellp();
    if(size>30000000) // removing the file if it size exceeds 3MB. New file will be created on next log statement.
        remove(fname);

}
