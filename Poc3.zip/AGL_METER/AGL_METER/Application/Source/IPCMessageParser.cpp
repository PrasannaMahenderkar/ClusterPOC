#include <QDebug>
#include "IPCMessageParser.h"

IPCMessageParser :: IPCMessageParser(const UINT8* data)
{
    LOG("IPCMessageParser() called");
    CHECK_POINTER_FOR_NULL(data);
	// Reading the data into member variables from IPC Frame received
    m_objIPCFrameData = IPCFrameData(data,data[3]);
    m_commandCounter = data[0];
    m_frameType = data[1];
    m_splitIndex = data[2];
    m_dataLength = data[3];
    m_blockChckCharacter = data[3 + m_dataLength];
    printData(data);
}

IPCMessageParser :: ~IPCMessageParser()
{
}

UINT8 IPCMessageParser :: getframeType() const
{
    return m_frameType;
}

IPCFrameData& IPCMessageParser :: getIPCFrameDataObj()
{
    return m_objIPCFrameData;
}


//prints data, commented argument to eliminate warning.
void IPCMessageParser :: printData(const UINT8* /*data*/) const
{	
    LOG("printData() called");

    /*for (int i=0; i < 37; i++)
           LOG("DataFrame "<<(int)data[i]);	*/

    LOG("m_commandCounter     : "<<(int)m_commandCounter);
    LOG("m_frameType          : "<<(int)m_frameType);
    LOG("m_splitIndex         : "<<(int)m_splitIndex);
    LOG("m_dataLength         : "<<(int)m_dataLength);
    LOG("m_blockChckCharacter : "<<(int)m_blockChckCharacter);

}
