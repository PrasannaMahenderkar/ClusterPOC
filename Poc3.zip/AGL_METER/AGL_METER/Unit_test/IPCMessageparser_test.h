#ifndef IPCMESSAGEPARSER_TEST_H
#define IPCMESSAGEPARSER_TEST_H
#include "gtest/gtest.h"
#include "IPCMessageParser.h"
using namespace testing;

// This class is used to test the functions of IPCMessageParser
class IPCMessageParser_test:public ::testing::Test
{
public:
    IPCMessageParser_test();
    ~IPCMessageParser_test();
    IPCMessageParser* mIPCMessageParser;
private:

    virtual void SetUp();
    virtual void TearDown();
};

#endif // IPCMESSAGEPARSER_TEST_H
