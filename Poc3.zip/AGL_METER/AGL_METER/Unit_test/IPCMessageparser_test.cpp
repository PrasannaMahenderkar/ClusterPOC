#include "IPCMessageparser_test.h"

IPCMessageParser_test::IPCMessageParser_test()
{

}

IPCMessageParser_test::~IPCMessageParser_test()
{

}

void IPCMessageParser_test::SetUp()
{

}

void IPCMessageParser_test::TearDown()
{
    if(mIPCMessageParser)
    {
        delete mIPCMessageParser;
        mIPCMessageParser = nullptr;
    }
}

//This test Case is Use for test Frame Type ---IPCData[1] is FrameType
TEST_F(IPCMessageParser_test,getframeType1)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {1,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    mIPCMessageParser = new IPCMessageParser(IPCData);

    //validate arguement
    EXPECT_EQ(IPCData[1],mIPCMessageParser->getframeType());
}

//This test Case is Use for test Frame Type ---IPCData[1] is FrameType
TEST_F(IPCMessageParser_test,getframeType2)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {1,30,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    mIPCMessageParser = new IPCMessageParser(IPCData);

    //validate arguement
    EXPECT_EQ(IPCData[1],mIPCMessageParser->getframeType());
}

//This test Case is Use for test Frame Type ---IPCData[1] is FrameType
TEST_F(IPCMessageParser_test,getframeType3)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {1,6,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    mIPCMessageParser = new IPCMessageParser(IPCData);

    //validate arguement
    EXPECT_EQ(IPCData[1],mIPCMessageParser->getframeType());
}






