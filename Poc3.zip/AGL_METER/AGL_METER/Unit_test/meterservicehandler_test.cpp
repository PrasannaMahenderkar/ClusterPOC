#include "meterservicehandler_test.h"

MeterServiceHandler_test::MeterServiceHandler_test()
{

}

MeterServiceHandler_test::~ MeterServiceHandler_test()
{

}

void MeterServiceHandler_test::SetUp()
{
    mMeterServiceHandlerObj = new MeterServiceHandler(nullptr);
}

void MeterServiceHandler_test::TearDown()
{
    if(mMeterServiceHandlerObj)
    {
        delete mMeterServiceHandlerObj;
        mMeterServiceHandlerObj = nullptr;
    }
}

//This test case is used for pasing  Command counter Once and check for call count of IPCDataFrameRecvEventSIG().
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOTOnce)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {1,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    //Creation of QJsonObject
    QJsonObject final_object;
    final_object.insert(QString("frame_data"), QJsonValue(FrameData));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),1);  // make sure the signal was emitted exactly one time

    //clear previous status
    spy.clear();
}

//This test case is to check call count of IPCDataFrameRecvEventSIG() when command counter is incremented Twice.
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOTTwice)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {2,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData1 = {3,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    //Creation of QJsonObject
    QJsonObject final_object;

    final_object.insert(QString("frame_data"), QJsonValue(FrameData));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    final_object.insert(QString("frame_data"), QJsonValue(FrameData1));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),2);  // make sure the signal was emitted exactly Two times

    //clear previous status
    spy.clear();
}

//This test case is to check call count of IPCDataFrameRecvEventSIG() when command counter is incremented Twice. Thrice.
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOTThrice)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {4,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData1 = {5,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData2 = {6,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    //Creation of QJsonObject
    QJsonObject final_object;

    final_object.insert(QString("frame_data"), QJsonValue(FrameData));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    final_object.insert(QString("frame_data"), QJsonValue(FrameData1));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    final_object.insert(QString("frame_data"), QJsonValue(FrameData2));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),3);  // make sure the signal was emitted exactly Three times

    //clear previous status
    spy.clear();
}

//This test case is used for passing  Command counter Increment by 1 and checking for call count of IPCDataFrameRecvEventSIG()
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOTIncSameCmdcntr)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {7,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData1 = {7,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData2 = {4,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    //Creation of QJsonObject
    QJsonObject final_object;

    final_object.insert(QString("frame_data"), QJsonValue(FrameData));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);


    final_object.insert(QString("frame_data"), QJsonValue(FrameData1));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);


    final_object.insert(QString("frame_data"), QJsonValue(FrameData2));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),1);  // make sure the signal was emitted exactly one time

    //clear previous status
    spy.clear();
}

//This test case is used for pasing Same Command counter and checking for call count of IPCDataFrameRecvEventSIG()
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOTSameCmdcntr)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {6,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};
    QJsonArray FrameData1 = {7,0,0,0,0,0,0,0,0,10,0,60,6,0,0,3,2,6,20,6,0,20,0,30,6,0,1,40,1,0,7,7,0};

    //Creation of QJsonObject
    QJsonObject final_object;

    final_object.insert(QString("frame_data"), QJsonValue(FrameData));

    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    final_object.insert(QString("frame_data"), QJsonValue(FrameData1));
    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),0);  // make sure the signal was not emitted.

    //clear previous status
    spy.clear();
}

//This test case is used for passing emptyJson and checking for call count of IPCDataFrameRecvEventSIG()
TEST_F(MeterServiceHandler_test,IPCDataFrameRecvEventSLOT_emptyJson)
{
    QSignalSpy spy(mMeterServiceHandlerObj, SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)));

    //Creation of QJsonObject
    QJsonObject final_object;

    mMeterServiceHandlerObj->IPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),0);  // make sure the signal was not emitted.

    //clear previous status
    spy.clear();
}




