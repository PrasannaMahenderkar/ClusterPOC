#ifndef METERSERVICEHANDLER_TEST_H
#define METERSERVICEHANDLER_TEST_H

#include "MeterServiceHandler.h"
#include<gtest/gtest.h>
#include <QSignalSpy>

class MeterServiceHandler_test:public ::testing::Test
{
public:
    MeterServiceHandler_test();
    ~ MeterServiceHandler_test();
    MeterServiceHandler* mMeterServiceHandlerObj;
private:
    virtual void SetUp();
    virtual void TearDown();


};

#endif // METERSERVICEHANDLER_TEST_H
