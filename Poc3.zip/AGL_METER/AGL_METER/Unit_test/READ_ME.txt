#To generate html report from xml, below is the command to execute in the Unit_Test Folder

xsltproc gtest2html.xslt MeterOutputGtest.xml > MeterOutputGtest.html
