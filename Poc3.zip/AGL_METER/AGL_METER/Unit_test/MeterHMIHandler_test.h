#ifndef METERHMIHANDLER_TEST_H
#define METERHMIHANDLER_TEST_H

#define private public
#include "MeterHMIHandler.h"
#undef private

#include "gtest/gtest.h"
#include <QSignalSpy>

#include "IPCFrameData.h"

using namespace std;
using namespace testing;

class MeterHMIHandler;
class IPCFrameData;

class MeterHMIHandler_test:public ::testing::Test
{
public:
    MeterHMIHandler_test();
    MeterHMIHandler* mMeterHMIHandler;
    IPCFrameData* mIPCFrameData;

    int litToBigEndianFourByte(int);
    unsigned short litToBigEndianTwoByte(unsigned short);
    int getIntData(const unsigned char* data,int, int) const;
private:
    virtual void SetUp();
    virtual void TearDown();
};

#endif // METERHMIHANDLER_TEST_H
