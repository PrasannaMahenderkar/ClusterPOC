#ifndef IPCFRAMEDATA_TEST_H
#define IPCFRAMEDATA_TEST_H
#include "gtest/gtest.h"
#include "IPCFrameData.h"
using namespace std;
using namespace testing;

// This class is used to test the litToBigEndianTwoByte() function of IPCFrameData
class IPCFrameDataTwoByteEndConv_Test: public TestWithParam<tuple<int,int>>
{
public:
    IPCFrameDataTwoByteEndConv_Test(){}
    ~IPCFrameDataTwoByteEndConv_Test(){}
    IPCFrameData* mIPCFrameData;
private:

    virtual void SetUp();
    virtual void TearDown();
};

// This class is used to test the litToBigEndianFourByte() function of IPCFrameData
class IPCFrameDataFourByteEndConv_Test: public TestWithParam<tuple<int,int>>
{
public:
    IPCFrameDataFourByteEndConv_Test(){}
    ~IPCFrameDataFourByteEndConv_Test(){}
    IPCFrameData* mIPCFrameData;
private:

    virtual void SetUp();
    virtual void TearDown();
};

// This class is used to test the getIntData() function of IPCFrameData
class IPCFrameData_Test: public TestWithParam<unsigned char[33]>
{
public:
    IPCFrameData_Test(){}
    ~IPCFrameData_Test(){}
    IPCFrameData* mIPCFrameData;
private:

    virtual void SetUp();
    virtual void TearDown();
};


#endif // IPCFRAMEDATA_TEST_H
