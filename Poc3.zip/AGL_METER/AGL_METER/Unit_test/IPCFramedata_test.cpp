#include "IPCFramedata_test.h"

void IPCFrameDataTwoByteEndConv_Test::SetUp()
{
    unsigned char IPCData[] = {00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,04,00,00};

    mIPCFrameData = new IPCFrameData(IPCData,sizeof(IPCData));
}

void IPCFrameDataTwoByteEndConv_Test::TearDown()
{
    if(mIPCFrameData)
    {
        delete mIPCFrameData;
        mIPCFrameData = nullptr;
    }
}

void IPCFrameDataFourByteEndConv_Test::SetUp()
{
    unsigned char IPCData[] = {00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,04,00,00};

    mIPCFrameData = new IPCFrameData(IPCData,sizeof(IPCData));
}

void IPCFrameDataFourByteEndConv_Test::TearDown()
{
    if(mIPCFrameData)
    {
        delete mIPCFrameData;
        mIPCFrameData = nullptr;
    }
}


void IPCFrameData_Test::SetUp()
{
    unsigned char IPCData[] = {00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,04,00,00};

    mIPCFrameData = new IPCFrameData(IPCData,sizeof(IPCData));
}

void IPCFrameData_Test::TearDown()
{
    if(mIPCFrameData)
    {
        delete mIPCFrameData;
        mIPCFrameData = nullptr;
    }
}

INSTANTIATE_TEST_CASE_P(
        TwoByteEndianConversionTest, IPCFrameDataTwoByteEndConv_Test, testing::Values(
            make_tuple(0x0003,0x0300),
            make_tuple(0x0004,0x0400),
            make_tuple(0x0030,0x3000),
            make_tuple(0x0865,0x6508),
            make_tuple(0x1735,0x3517),
            make_tuple(0x9821,0x2198)
            ));

//This test case is used for checking litToBigEndianTwoByte().
TEST_P(IPCFrameDataTwoByteEndConv_Test,litToBigEndianTwoByte)
{
    int inputData = std::get<0>(GetParam());
    //validate arguement
    EXPECT_EQ(std::get<1>(GetParam()),mIPCFrameData->litToBigEndianTwoByte(inputData));
}

INSTANTIATE_TEST_CASE_P(FourByteEndianConversionTest, IPCFrameDataFourByteEndConv_Test, testing::Values(
                            make_tuple(0x03000000,0x00000003),
                            make_tuple(0x16003500,0x00350016),
                            make_tuple(0x16354923,0x23493516),
                            make_tuple(0x36196523,0x23651936),
                            make_tuple(0x17353649,0x49363517),
                            make_tuple(0x98213256,0x56322198)
                            ));

//This test case is used for checking litToBigEndianFourByte().
TEST_P(IPCFrameDataFourByteEndConv_Test,litToBigEndianFourByte)
{
    int inputData = std::get<0>(GetParam());

    //validate arguement
    EXPECT_EQ(std::get<1>(GetParam()),mIPCFrameData->litToBigEndianFourByte(inputData));
}

//This test case is used for checking Instant Fuel value form getIntData().
TEST_F(IPCFrameData_Test,getIntData_InstantFuel)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[33]= {00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,04,00,00};

    //validate arguement
    EXPECT_EQ(0x0400,mIPCFrameData->getIntData(IPCData,2,30)); //expect 0x0400 value of Instant Fuel
}

//This test case is used for checking Average Fuel value form getIntData().
TEST_F(IPCFrameData_Test,getIntData_AvgFuel)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[33]= {00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,06,00,00,00,04,00,00};

    //validate arguement
    EXPECT_EQ(0x0600,mIPCFrameData->getIntData(IPCData,2,26)); //expect 0x0600 value of Average Fuel
}

//This test case is used for checking Analog Speed Value form getIntData().
TEST_F(IPCFrameData_Test,getIntData_AnalogSpeedValue)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[33]= {00,00,00,00,00,00,00,00,0xFF,0xFF,00,00,00,00,00,00,00,00,00,00,00,00,01,00,00,02,00,03,00,02,00,03,00};

    //validate arguement
    EXPECT_EQ(0xFFFF,mIPCFrameData->getIntData(IPCData,2,8)); //expect 0xFFFF value of AnalogSpeedValue
}

