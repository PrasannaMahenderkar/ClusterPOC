#include "MeterHMIHandler_test.h"

MeterHMIHandler_test::MeterHMIHandler_test()
{

}

void MeterHMIHandler_test::SetUp()
{
    mMeterHMIHandler = new MeterHMIHandler(nullptr,nullptr);

}

void MeterHMIHandler_test::TearDown()
{
    if(mMeterHMIHandler)
    {
        delete mMeterHMIHandler;
        mMeterHMIHandler = nullptr;
    }
}

int MeterHMIHandler_test :: litToBigEndianFourByte(int data)
{
    int bigdata = (((data>>24) & 0x000000ff) | ((data>>8) & 0x0000ff00) | ((data<<8) & 0x00ff0000) | ((data<<24) & 0xff000000));
    return bigdata;
}

unsigned short MeterHMIHandler_test :: litToBigEndianTwoByte(unsigned short data)
{
    unsigned short bigdata = (((data >> 8)&0x00FF)  | ((data << 8)& 0xFF00));

    return bigdata ;
}

int MeterHMIHandler_test :: getIntData(const unsigned char* IPCData,int byteSize, int start) const
{
    int dataValue = 0;
    if(4 == byteSize)
    {

        dataValue = ((((IPCData[start] << 24)| IPCData[start+1]<<16)| IPCData[start+2]<<8) |IPCData[start+3]);
    }
    else if (2 == byteSize)
    {
        dataValue = IPCData[start] << 8 | IPCData[start + 1];
    }
    return dataValue;
}

//This Test case is used to check for call count of screendataChanged().
TEST_F(MeterHMIHandler_test,processIPCDataFrameRecvEventSLOT)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {19,0,17,28,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13};

    //Creation of QJsonObject
    QJsonObject final_object;
    final_object.insert(QString("frame_data"), QJsonValue(FrameData));

    mMeterHMIHandler->processIPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),1);  // make sure the signal was emitted exactly one time

    //clear previous status
    spy.clear();
}

//This test case is used for passing Empty Json Array and check for call count of screendataChanged().
TEST_F(MeterHMIHandler_test,processIPCDataFrameRecvEventSLOT_emptyArray)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of QJsonArray
    QJsonArray FrameData = {};

    //Creation of QJsonObject
    QJsonObject final_object;
    final_object.insert(QString("frame_data"), QJsonValue(FrameData));

    mMeterHMIHandler->processIPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),0);  // make sure the signal was not emitted.

    //clear previous status
    spy.clear();
}

//This test case is used for passing Empty Json and check for call count of screendataChanged()
TEST_F(MeterHMIHandler_test,processIPCDataFrameRecvEventSLOT_EmptyJson)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of QJsonObject
    QJsonObject final_object;

    mMeterHMIHandler->processIPCDataFrameRecvEventSLOT(final_object);

    //validate arguement
    EXPECT_EQ(spy.count(),0);  // make sure the signal was not emitted.

    //clear previous status
    spy.clear();
}

//This test case is for Maximum Input value and check if the values are set.
TEST_F(MeterHMIHandler_test,updateHMIScreen_Max)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               0xFF,0xFF, //SPEED
                               00,00,
                               0x3F,0x42,0x0F,00, //OdoValue
                               0x3F,0x42,0x0F,00, //TripValue
                               00,00,
                               01, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               100, //GaugeWaterTemp
                               00,
                               02, //AverageFuelUnit
                               0xE7,03, //AverageFuel
                               00,
                               02, //InstantFuelUnit
                               0xE7,03, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);

    const size_t dataSize = 0;
    mIPCFrameData = new IPCFrameData(IPCData,dataSize);

    //validate arguement
    EXPECT_EQ(spy.count(), 1); // make sure the signal was emitted exactly one time
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData, 2, 8))),mIPCFrameData->getAnalogVehicleSpeed());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),mIPCFrameData->getTrip());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),mIPCFrameData->getODO());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),mIPCFrameData->getAvgFuel());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),mIPCFrameData->getInstantFuel());
    EXPECT_EQ(IPCData[25],mIPCFrameData->getAvgFuelUnit());
    EXPECT_EQ(IPCData[29],mIPCFrameData->getInstantFuelUnit());
    QString distanceUnit = QString::fromStdString(mIPCFrameData->getDistanceUnit());
    EXPECT_EQ("miles",distanceUnit);
    delete mIPCFrameData;
    mIPCFrameData = nullptr;

    //clear previous status
    spy.clear();
}

//This test case is for passing Minimum Input value and check if the values are set in mScreenData JsonObject.
TEST_F(MeterHMIHandler_test,updateHMIScreen_screenData)
{
    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               0xFF,0xFF, //SPEED
                               00,00,
                               0x3F,0x42,0x0F,00, //OdoValue
                               0x3F,0x42,0x0F,00, //TripValue
                               00,00,
                               01, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               100, //GaugeWaterTemp
                               00,
                               02, //AverageFuelUnit
                               0xE7,03, //AverageFuel
                               00,
                               02, //InstantFuelUnit
                               0xE7,03, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);
    QJsonObject obj = mMeterHMIHandler->screendata();

    //validate arguement
    EXPECT_EQ(litToBigEndianTwoByte(getIntData(IPCData, 2, 8)),obj.value("speed").toInt());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),obj.value("TripValue").toInt());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),obj.value("OdoValue").toInt());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),obj.value("AverageFuel").toInt());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),obj.value("InstantFuel").toInt());
}

//This test case is for passing Minimum Input value and check if the values are set
TEST_F(MeterHMIHandler_test,updateHMIScreen_Min)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               00,00, //SPEED
                               00,00,
                               00,00,00,00, //OdoValue
                               00,00,00,00, //TripValue
                               00,00,
                               00, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               00, //GaugeWaterTemp
                               00,
                               00, //AverageFuelUnit
                               00,00, //AverageFuel
                               00,
                               00, //InstantFuelUnit
                               00,00, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);

    const size_t dataSize = 0;
    mIPCFrameData = new IPCFrameData(IPCData,dataSize);

    //validate arguement
    EXPECT_EQ(spy.count(), 1);  // make sure the signal was emitted exactly one time
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData, 2, 8))),mIPCFrameData->getAnalogVehicleSpeed());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),mIPCFrameData->getTrip());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),mIPCFrameData->getODO());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),mIPCFrameData->getAvgFuel());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),mIPCFrameData->getInstantFuel());
    EXPECT_EQ(IPCData[25],mIPCFrameData->getAvgFuelUnit());
    EXPECT_EQ(IPCData[29],mIPCFrameData->getInstantFuelUnit());
    QString distanceUnit = QString::fromStdString(mIPCFrameData->getDistanceUnit());
    EXPECT_EQ("km",distanceUnit);
    delete mIPCFrameData;
    mIPCFrameData = nullptr;

    //clear previous status
    spy.clear();
}

//This test case is for passing In-Between Input value and check if the values are set
TEST_F(MeterHMIHandler_test,updateHMIScreen_InBetween)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               00,9, //SPEED
                               00,00,
                               00,10,00,00, //OdoValue
                               00,0x9,00,00, //TripValue
                               00,00,
                               00, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               50, //GaugeWaterTemp
                               00,
                               01, //AverageFuelUnit
                               00,01, //AverageFuel
                               00,
                               01, //InstantFuelUnit
                               00,02, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);

    const size_t dataSize = 0;
    mIPCFrameData = new IPCFrameData(IPCData,dataSize);

    //validate arguement
    EXPECT_EQ(spy.count(), 1);  // make sure the signal was emitted exactly one time
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData, 2, 8))),mIPCFrameData->getAnalogVehicleSpeed());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),mIPCFrameData->getTrip());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),mIPCFrameData->getODO());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),mIPCFrameData->getAvgFuel());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),mIPCFrameData->getInstantFuel());
    EXPECT_EQ(IPCData[25],mIPCFrameData->getAvgFuelUnit());
    EXPECT_EQ(IPCData[29],mIPCFrameData->getInstantFuelUnit());
    QString distanceUnit = QString::fromStdString(mIPCFrameData->getDistanceUnit());
    EXPECT_EQ("km",distanceUnit);
    delete mIPCFrameData;
    mIPCFrameData = nullptr;

    //clear previous status
    spy.clear();
}

//#################################################################################################
//        Negative Test Cases
//#################################################################################################

//Negative Test Case by passing Maximum input value to updateHMIScreen().
TEST_F(MeterHMIHandler_test,updateHMIScreen_NegativeTestCase_1)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               00,9, //SPEED
                               00,00,
                               00,10,00,00, //OdoValue
                               00,0x9,00,00, //TripValue
                               00,00,
                               03, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               50, //GaugeWaterTemp
                               00,
                               04, //AverageFuelUnit
                               00,01, //AverageFuel
                               03, //Avelage Fuel Status
                               04, //InstantFuelUnit  set default
                               00,03, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);

    const size_t dataSize = 0;
    mIPCFrameData = new IPCFrameData(IPCData,dataSize);

    //validate arguement
    EXPECT_EQ(spy.count(), 1);  // make sure the signal was emitted exactly one time
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData, 2, 8))),mIPCFrameData->getAnalogVehicleSpeed());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),mIPCFrameData->getTrip());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),mIPCFrameData->getODO());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),mIPCFrameData->getAvgFuel());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),mIPCFrameData->getInstantFuel());
    EXPECT_EQ("",mIPCFrameData->getUnit(mIPCFrameData->getAvgFuelUnit()));
    EXPECT_EQ("",mIPCFrameData->getUnit(mIPCFrameData->getInstantFuelUnit()));
    QString distanceUnit = QString::fromStdString(mIPCFrameData->getDistanceUnit());
    EXPECT_NE(0,mIPCFrameData->getAvgFuelStatus());
    EXPECT_NE("",distanceUnit);
    delete mIPCFrameData;
    mIPCFrameData = nullptr;

    //clear previous status
    spy.clear();
}

//Negative Test Case by passing Maximum input value to updateHMIScreen().
TEST_F(MeterHMIHandler_test,updateHMIScreen_NegativeTestCase_2)
{
    QSignalSpy spy(mMeterHMIHandler, SIGNAL(screendataChanged(QJsonObject)));

    //Creation of unsigned char IPCData[]
    unsigned char IPCData[] = {00,00,00,00,00,00,
                               00,00,
                               00,03, //SPEED
                               00,00,
                               00,10,00,00, //OdoValue
                               00,0x9,00,00, //TripValue
                               00,00,
                               07, // (Distance Unit )TripUnit,OdoUnit,SpeedUnit
                               50, //GaugeWaterTemp
                               00,
                               05, //AverageFuelUnit
                               00,01, //AverageFuel
                               05, //Avelage Fuel Status
                               06, //InstantFuelUnit  set default
                               00,04, //InstantFuel
                               00};

    mMeterHMIHandler->updateHMIScreen(IPCData);

    const size_t dataSize = 0;
    mIPCFrameData = new IPCFrameData(IPCData,dataSize);

    //validate arguement
    EXPECT_EQ(spy.count(), 1);  // make sure the signal was emitted exactly one time
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData, 2, 8))),mIPCFrameData->getAnalogVehicleSpeed());
    EXPECT_EQ((litToBigEndianFourByte(getIntData(IPCData,4, 16))),mIPCFrameData->getTrip());
    EXPECT_EQ(litToBigEndianFourByte(getIntData(IPCData,4, 12)),mIPCFrameData->getODO());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2, 26))),mIPCFrameData->getAvgFuel());
    EXPECT_EQ((litToBigEndianTwoByte(getIntData(IPCData,2,30))),mIPCFrameData->getInstantFuel());
    EXPECT_EQ("",mIPCFrameData->getUnit(mIPCFrameData->getAvgFuelUnit()));
    EXPECT_EQ("",mIPCFrameData->getUnit(mIPCFrameData->getInstantFuelUnit()));
    QString distanceUnit = QString::fromStdString(mIPCFrameData->getDistanceUnit());
    EXPECT_NE(0,mIPCFrameData->getAvgFuelStatus());
    EXPECT_NE("",distanceUnit);
    delete mIPCFrameData;
    mIPCFrameData = nullptr;

    //clear previous status
    spy.clear();
}

