#include "integrationTester.h"
#include "ui_integrationTester.h"

#include <QJsonDocument>
#include <QDebug>
#include <QStringList>
#include <QDateTime>

// Printing support
#include <QtPrintSupport/QPrinter>
#include <QDir>

// application tester classes
#include "integrationTestHelper.h"

IntegrationTester::IntegrationTester(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::IntegrationTester),
    mLogEvents(false),
    mStatisticsLoggedForSelection(true)
{
    ui->setupUi(this);

    init();
}

IntegrationTester::~IntegrationTester()
{
    delete ui;
    cleanup();
}

void IntegrationTester::init()
{
    mHelperObj = new IntegrationTestHelper();

    if(mHelperObj != nullptr)
    {
        connect(mHelperObj, SIGNAL(serviceEventReceivedSIG(QJsonObject)),
            this,SLOT(serviceEventReceivedSLOT(QJsonObject)));
    }
    // Create List widget
    ui->listWidget->addItems(optionsList);
   //********

     mHelperObj->executeSelectedOption(mInputArg);
     //*********
    mReceivedEventList.clear();

}

void IntegrationTester::cleanup()
{
    if(mHelperObj)
    {
        delete mHelperObj;
    }
}

void IntegrationTester::on_closeButton_clicked()
{
    // close the widget
    close();
}

void IntegrationTester::displayReqParamsForSelection()
{
    ui->txtReqParams->clear();
    QStringList reqParams = mHelperObj->getReqParamsForSelection();
    foreach (QString param, reqParams)
    {
        ui->txtReqParams->appendPlainText(param);
    }
}

void IntegrationTester::displayPreRequisitesForSelection()
{
    ui->txtPreRequisites->clear();
    QStringList preRequisites = mHelperObj->getPreRequisitesForSelection();
    foreach (QString param, preRequisites)
    {
        ui->txtPreRequisites->appendPlainText(param);
    }
}

void IntegrationTester::updateExepctedEventsForSelection()
{
    ui->txtExpEvents->clear();
    if(mHelperObj->getSelectedOption() != IntegrationTestHelper::NONE_SELECTED)
    {
        QStringList listExpected = expectedEventMap.value(mSelectedOptionText);
        foreach (QString txtEvent, listExpected)
        {
            ui->txtExpEvents->appendPlainText(txtEvent);
        }
    }
}

QStringList IntegrationTester::getListOfMissedEventsForSelection()
{
    QStringList missedEvents;
    QStringList listExpected = expectedEventMap.value(mSelectedOptionText);
    foreach (QString txtEvent, listExpected)
    {
        int index = mReceivedEventList.indexOf(QRegExp(txtEvent, Qt::CaseInsensitive), 0);
        if(index == -1)
        {
            missedEvents.append(txtEvent);
        }
    }
    return missedEvents;
}

void IntegrationTester::logCurrentSelection()
{
    ui->txtResultBox->appendPlainText("=============================================");
    ui->txtResultBox->appendPlainText("Selected Option: " + mSelectedOptionText);
    ui->txtResultBox->appendPlainText("=============================================");
}

void IntegrationTester::logReceivedEventInformation(QJsonObject data)
{
    ui->txtResultBox->appendPlainText("=========================");
    ui->txtResultBox->appendPlainText("Event: " + data.value("Event").toString());
    ui->txtResultBox->appendPlainText("Data: ");
    ui->txtResultBox->appendPlainText("===========");
    data.remove("Event");
    QJsonDocument doc(data);
    ui->txtResultBox->appendPlainText(doc.toJson());
    ui->txtResultBox->appendPlainText("===========");
    ui->txtResultBox->appendPlainText("=========================");
}

void IntegrationTester::logStatisticsOfSelection(bool bLogFailure)
{
    if(mStatisticsLoggedForSelection)
        return;

    QStringList missedEvents = getListOfMissedEventsForSelection();
    if(missedEvents.empty())
    {
        // Stop logging now, till next selection
        mLogEvents = false;

        ui->txtResultBox->appendPlainText("=============================================");
        ui->txtResultBox->appendPlainText(mSelectedOptionText + " completed successfully");
        ui->txtResultBox->appendPlainText("=============================================");

        mStatisticsLoggedForSelection = true;
    }
    else
    {
        // Failures should be logged only when demanded
        // it might be case that we are checking intermittently for results
        // or selected option is not completely executed yet
        if(bLogFailure && mLogEvents)
        {
            ui->txtResultBox->appendPlainText("=============================================");
            ui->txtResultBox->appendPlainText(mSelectedOptionText + " failed.");
            ui->txtResultBox->appendPlainText("Failed Events:");
            foreach (QString eventStr, missedEvents) {
                ui->txtResultBox->appendPlainText(eventStr);
            }
            ui->txtResultBox->appendPlainText("=============================================");

            mStatisticsLoggedForSelection = true;
        }
    }
}

void IntegrationTester::on_listWidget_itemSelectionChanged()
{
    // Log Statistics of last selection, before changing the selection
    logStatisticsOfSelection(true);

    QListWidgetItem *item = ui->listWidget->currentItem();
    mSelectedOptionText = item->text();

    //TODO: If order of list item changes, please modify enumeration type SelectedOption accordingly
    mHelperObj->setSelectedOption((IntegrationTestHelper::SelectedOption)ui->listWidget->currentRow());

    qDebug() << "Selected Option: "<< mSelectedOptionText;
    qDebug() << "Selected Index:" << ui->listWidget->currentRow();

    mInputArg.clear();
    ui->editInput->clear();
    mReceivedEventList.clear();

    // On selection change, stop logging any events (till execute event)
    mLogEvents = false;

    // mark for statistics logging
    mStatisticsLoggedForSelection = false;

    displayReqParamsForSelection();
    displayPreRequisitesForSelection();
    updateExepctedEventsForSelection();

    logCurrentSelection();
}

void IntegrationTester::on_editInput_textChanged()
{
    // New line seperated inputs
    // parse before further processing as per requirement
    mInputArg = ui->editInput->toPlainText();
}

void IntegrationTester::on_saveButton_clicked()
{
    // Create folder for integration report, if not already there
    if (! QDir(reportFolder).exists())
    {
        QDir().mkdir(reportFolder);
    }

    QString currentTime = QDateTime::currentDateTime().toString("_ddMMyyyy_HH_mm");
    QString fileName = reportFolder + "/" + reportFilePrefix + currentTime  + ".pdf";

    qDebug() << " File saved to: " << fileName;

    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName(fileName);

    // Print report to PDF file
    ui->txtResultBox->print(&printer);

    // Display path to user
    ui->txtSavedPath->setText("Report saved to:" + fileName);
}

void IntegrationTester::on_clearButton_clicked()
{
    // clearing out the text from result box
    ui->txtResultBox->clear();
}

void IntegrationTester::serviceEventReceivedSLOT(QJsonObject data)
{
    if(!mLogEvents)
        return;

    mReceivedEventList.append(data.value("Event").toString());

    logReceivedEventInformation(data);

    // Validate the events received against list of events expected in particular case
    logStatisticsOfSelection(false);
}

void IntegrationTester::on_executeButton_clicked()
{
    // Start logging events
    mLogEvents = true;

    mHelperObj->executeSelectedOption(mInputArg);
}
