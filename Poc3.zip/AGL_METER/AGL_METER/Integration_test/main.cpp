#include "integrationTester.h"
#include <QApplication>
#include <QRect>
#include <QDesktopWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    IntegrationTester w;

    w.setFixedSize(w.width(),w.height());
    w.rect().center();

    w.show();

    return a.exec();
}
