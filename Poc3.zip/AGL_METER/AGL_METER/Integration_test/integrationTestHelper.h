#ifndef INTEGRATIONTESTHELPER_H
#define INTEGRATIONTESTHELPER_H

#include <QObject>
#include <QMap>
#include <QStringList>
#include <QJsonObject>
#include "MeterServiceHandler.h"

//Forward declarations
class MeterServiceHandler;

const QStringList optionsList =
{
    "Subscribe-Event"
};

const QMap<QString,QStringList> expectedEventMap =
{
    {optionsList.at(0), {"FT0"}}
};

const QString reportFolder = "/home/ipc_service/Meter_Interation_Test_Result";
const QString reportFilePrefix ="Meter";

class IntegrationTestHelper : public QObject
{
    Q_OBJECT
public:

    enum SelectedOption
    {
        SUBSCRIBE_EVENT = 0,
        NONE_SELECTED
    };

    explicit IntegrationTestHelper(QObject *parent = nullptr);
    ~IntegrationTestHelper();

    // Description: Establish connection with service handler class
    void init();

    //Description : Release allocated memory
    void cleanup();

    //Description : Getter to for selected item
    SelectedOption getSelectedOption() const;

    //Description : Setter function to set selected event
    void setSelectedOption(const SelectedOption& option);

    //Description : Get list of parameter required for selected event
    QStringList getReqParamsForSelection();

    //Description : List of preconditions for selected event
    QStringList getPreRequisitesForSelection();

    //Description : Run selected event
    void executeSelectedOption(QString arg);

signals:
    void serviceEventReceivedSIG(QJsonObject);

public slots:
    void serviceEventReceivedSLOT(QJsonObject data);

private:

    // Current selected Option Tracking
    SelectedOption mSelectedOption;
    // Previous selected Option Tracking
    SelectedOption mPrevSelection;
    MeterServiceHandler* mMeterServiceHandler;

};

#endif // INTEGRATIONTESTHELPER_H
