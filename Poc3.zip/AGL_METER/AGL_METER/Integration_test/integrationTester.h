#ifndef INTEGRATIONTESTER_H
#define INTEGRATIONTESTER_H

#include <QMainWindow>
#include <QListWidgetItem>
#include <QString>
#include <QJsonObject>

//Forward declaration
class IntegrationTestHelper;

namespace Ui {
class IntegrationTester;
}

class IntegrationTester : public QMainWindow
{
    Q_OBJECT

public:
    explicit IntegrationTester(QWidget *parent = 0);
    ~IntegrationTester();

private slots:
    //Description : Close the application
    void on_closeButton_clicked();

    //Description : Reset all required parameter when new event is selected from list.
    void on_listWidget_itemSelectionChanged();

    //Description :Modify input in textbox
    void on_editInput_textChanged();

    //Description :Save report in pdf form
    void on_saveButton_clicked();

    //Description :Clear output window
    void on_clearButton_clicked();

    //Description :Execute selected event
    void on_executeButton_clicked();

    //Description :Emit signal when data receieved from service
    void serviceEventReceivedSLOT(QJsonObject data);

private:
    //Description :Connect with UI and intilise event list
    void init();

    //Description :Ensure proper clean up and release of allocated memory
    void cleanup();

    //Description :display parameter list for selected event
    void displayReqParamsForSelection();

    //Description :Preconditions required for selected event
    void displayPreRequisitesForSelection();

    //Description :Actual event recieved from service for selected event from list
    void updateExepctedEventsForSelection();

    //Description : List all missed event
    QStringList getListOfMissedEventsForSelection();

    //Description : Print log for selected event in output box
    void logCurrentSelection();

    //Description : Print data log for selected event in output box
    void logReceivedEventInformation(QJsonObject data);

    //Description : Print log for last event or take log in case of failure
    void logStatisticsOfSelection(bool bLogFailure);

    Ui::IntegrationTester *ui;

    // Selected option tracking
    QString mSelectedOptionText;

    // Input arg entered by user. (currently, only one agruement support is given)
    QString mInputArg;

    // Used to see if event logging is to be sued or not
    bool mLogEvents;

    // Keep track of events received fro selected option
    QStringList mReceivedEventList;

    // Check if statistics is logged already or not
    bool mStatisticsLoggedForSelection;

    IntegrationTestHelper* mHelperObj;
};

#endif // INTEGRATIONTESTER_H
