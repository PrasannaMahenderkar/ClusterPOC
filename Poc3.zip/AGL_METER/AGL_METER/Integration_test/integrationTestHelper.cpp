#include "integrationTestHelper.h"
#include "MeterServiceHandler.h"

// There can be multiple input arguements required for selected option
// Our case does not require mulitple inputs. But, application can support it
const QMap<IntegrationTestHelper::SelectedOption, QStringList> reqParamList =
{
    { IntegrationTestHelper::SUBSCRIBE_EVENT, {"None"}}
};

// List down prerequisites for respective selections
const QMap<IntegrationTestHelper::SelectedOption, QStringList> preRequisiteList =
{
    { IntegrationTestHelper::SUBSCRIBE_EVENT, {"None"}}
};


IntegrationTestHelper::IntegrationTestHelper(QObject *parent) : QObject(parent)
{
    init();
}

IntegrationTestHelper::~IntegrationTestHelper()
{
    cleanup();
}

void IntegrationTestHelper::init()
{
    mMeterServiceHandler = new MeterServiceHandler(nullptr);
    if(mMeterServiceHandler != nullptr)
    {
        connect(mMeterServiceHandler,SIGNAL(IPCDataFrameRecvEventSIG(QJsonObject)),this,SLOT(serviceEventReceivedSLOT(QJsonObject)));

    }
}
void IntegrationTestHelper::cleanup()
{
    disconnect(mMeterServiceHandler);
    if (mMeterServiceHandler)
    {
        delete mMeterServiceHandler;
        mMeterServiceHandler = nullptr;
    }
}

IntegrationTestHelper::SelectedOption IntegrationTestHelper::getSelectedOption() const
{
    return mSelectedOption;
}

void IntegrationTestHelper::setSelectedOption(const SelectedOption& option)
{
    mPrevSelection = mSelectedOption;
    mSelectedOption = option;
}

void IntegrationTestHelper::serviceEventReceivedSLOT(QJsonObject data)
{
    emit serviceEventReceivedSIG(data);
}

QStringList IntegrationTestHelper::getReqParamsForSelection()
{
    QStringList reqParams;

    if(mSelectedOption != NONE_SELECTED)
    {
        if(reqParamList.find(mSelectedOption) != reqParamList.end())
        {
            reqParams = reqParamList.value(mSelectedOption);
        }
    }

    return reqParams;
}

QStringList IntegrationTestHelper::getPreRequisitesForSelection()
{
    QStringList preRequiresites;
    if(preRequisiteList.find(mSelectedOption) != preRequisiteList.end())
    {
        preRequiresites = preRequisiteList.value(mSelectedOption);
    }

    return preRequiresites;
}

void IntegrationTestHelper::executeSelectedOption(QString /*arg*/)
{
    // Do nothing. Event will be received from service
}
