////////////////////////////////////////////////////////////////////////////////
// NAME:  Meter.h
// DESCRIPTION:  Implementation of meter class
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////

#ifndef METER_H
#define METER_H

#include <QObject>
#include "messageengine.h"
#include "MeterMessage.h"

class Meter:public QObject
{	
	Q_OBJECT
	public:
	/**
     * @brief Constructor
     */
	explicit Meter(QUrl & url, QObject * parent = Q_NULLPTR);
	
	/**
     * @brief Destructor
     */
	virtual ~Meter();
	
	//MeterMessage *m_MeterMessage;
	
	/**
     * @brief Form connection with websocket
     */
	void onConnected();
	
	/**
     * @brief Disconnect connection form with websocket
     */
	void onDisconnected();
	
	/**
     * @brief Receive  data frame from websocket
	 * @param MessageType : type of Event message
	 * @param Message : data
     */
	void onMessageReceived(MessageType type, Message *message);

	signals:
	/**
     * @brief Send this signal when data frame is received
	 * @param QJsonObject : frame data
     */
	void IPCdataFrameReceived(const QJsonObject& data);

	private:
	MessageEngine * m_loop;

	const QStringList m_events 
	{
     "FT0",
    };

};
#endif // METER_H
