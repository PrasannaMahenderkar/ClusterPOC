////////////////////////////////////////////////////////////////////////////////
// NAME:  MeterMessage.h
// DESCRIPTION:  This class handles parsing of data frame.
//
// COPYRIGHT NOTICE:
// (C) KPIT Technologies Ltd
// Created in 2018 as an unpublished copyright work.
// All rights reserved.
// This document & the information it contains is confidential
// and proprietary to KPIT Technologies Ltd.  Hence, it may not be used, copied,
// reproduced, transmitted, or stored in any form or by any
// means, electronic, recording, photocopying, mechanical or
// otherwise, without the prior written permission of KPIT Technologies Ltd
//
/////////////////////////////////////////////////////////////////////////////////
#ifndef METER_MESSAGE_H
#define METER_MESSAGE_H

#include "message.h"

class MeterMessage : public Message
{
Q_OBJECT
public:
	/**
     * @brief Send requst to service recievd from QT application
	 * @param QString : request type
	 * @param QJsonObject : parameter
	 * @return bool : status
     */
	bool createRequest(QString verb, QJsonObject parameter);
	
	/**
     * @brief Check  if event is FT) or not
	 * @return bool: true/false
     */
	bool isIPCDataFT0Event();

};
#endif // METER_MESSAGE_H
