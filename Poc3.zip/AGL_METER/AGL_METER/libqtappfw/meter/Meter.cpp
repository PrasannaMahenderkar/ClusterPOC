#include "Meter.h"
#include "responsemessage.h"
Meter::Meter (QUrl &url,QObject * parent) :
    QObject(parent),
    m_loop(nullptr)
{
    m_loop = new MessageEngine(url);
    QObject::connect(m_loop, &MessageEngine::connected, this, &Meter::onConnected);
    QObject::connect(m_loop, &MessageEngine::disconnected, this, &Meter::onDisconnected);
    QObject::connect(m_loop, &MessageEngine::messageReceived, this, &Meter::onMessageReceived);
}

Meter::~Meter()
{
	if(m_loop != nullptr)
	{
		delete m_loop;
		m_loop = nullptr;
	}
}

//gets called from websocket

void Meter::onConnected()
{
    QStringListIterator eventIterator(m_events);
    MeterMessage *tmsg;

    while (eventIterator.hasNext()) {
        tmsg = new MeterMessage();
        QJsonObject parameter;
        parameter.insert("frame_type", eventIterator.next());
        tmsg->createRequest("subscribe", parameter);
		if(m_loop != nullptr)
			m_loop->sendMessage(tmsg);
        delete tmsg;
    }
}

//gets called from websocket

void Meter::onDisconnected()
{
    QStringListIterator eventIterator(m_events);
    MeterMessage *tmsg;

    while (eventIterator.hasNext()) {
        tmsg = new MeterMessage();
        QJsonObject parameter;
        parameter.insert("frame_type", eventIterator.next());
        tmsg->createRequest("unsubscribe", parameter);
		if(m_loop != nullptr)
			m_loop->sendMessage(tmsg);
        delete tmsg;
    }
}
void Meter::onMessageReceived(MessageType type, Message *message)
{
	
	if(message == nullptr) 
		return;
    if (type == IpcEventMessage){        
        MeterMessage *tmsg = qobject_cast<MeterMessage*>(message);
        if((tmsg != nullptr)&&(tmsg->isEvent())) {
             emit IPCdataFrameReceived(tmsg->eventData());
        }
    }
     message->deleteLater();
}
 
