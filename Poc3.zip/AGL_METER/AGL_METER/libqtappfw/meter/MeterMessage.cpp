#include <QJsonObject>
#include "MeterMessage.h"

bool MeterMessage::createRequest(QString verb, QJsonObject parameter){
	
	QStringList verbs {"subscribe", "unsubscribe"};
	if (!verbs.contains(verb))
		return false;

	return Message::createRequest("ipc", verb, parameter);
}

bool MeterMessage::isIPCDataFT0Event(){
	return(this->eventName() == "FT0");
	}