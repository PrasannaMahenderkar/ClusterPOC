#ifndef MEDIASCANNER_H
#define MEDIASCANNER_H

#include <QObject>
#include "messageengine.h"

class MediaScanner : public QObject
{
    Q_OBJECT
public:
    explicit MediaScanner(QUrl &url,QObject *parent = nullptr);
    virtual ~MediaScanner();

signals:
    void mediaUSBEvents(QString mediaEvent);

public slots:
private:
    MessageEngine *m_mloop;
    void onConnected();
    void onDisconnected();
    void onMessageReceived(MessageType, Message*);

    const QStringList mediascanner_events {
        "media_added",
        "media_removed"
    };
};

#endif // MEDIASCANNER_H
