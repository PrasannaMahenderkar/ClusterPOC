#include "message.h"
#include "messageengine.h"
#include "mediascanner.h"
#include "mediascannermessage.h"

MediaScanner::MediaScanner(QUrl &url, QObject *parent) : QObject(parent),m_mloop(nullptr)
{
    m_mloop = new MessageEngine(url);
    QObject::connect(m_mloop, &MessageEngine::connected, this, &MediaScanner::onConnected);
    QObject::connect(m_mloop, &MessageEngine::disconnected, this, &MediaScanner::onDisconnected);
    QObject::connect(m_mloop, &MessageEngine::messageReceived, this, &MediaScanner::onMessageReceived);

}

void MediaScanner::onConnected()
{
    QStringListIterator mediascanner_eventIterator(mediascanner_events);
    MediascannerMessage *mediascanner_tmsg;

    while (mediascanner_eventIterator.hasNext()) {
        mediascanner_tmsg = new MediascannerMessage();
        QJsonObject parameter;
        parameter.insert("value", mediascanner_eventIterator.next());
        mediascanner_tmsg->createRequest("subscribe", parameter);
        m_mloop->sendMessage(mediascanner_tmsg);
        delete mediascanner_tmsg;
    }
}

MediaScanner::~MediaScanner()
{
    delete m_mloop;
}

void MediaScanner::onDisconnected()
{
    QStringListIterator mediascanner_eventIterator(mediascanner_events);
    MediascannerMessage *mediascanner_tmsg;


    while (mediascanner_eventIterator.hasNext()) {
        mediascanner_tmsg = new MediascannerMessage();
        QJsonObject parameter;
        parameter.insert("value", mediascanner_eventIterator.next());
        mediascanner_tmsg->createRequest("unsubscribe", parameter);
        m_mloop->sendMessage(mediascanner_tmsg);
        delete mediascanner_tmsg;
    }
}

void MediaScanner::onMessageReceived(MessageType type, Message *message)
{
    if (type == MediascannerEventMessage) {
        MediascannerMessage *tmsg = qobject_cast<MediascannerMessage*>(message);

        if (tmsg->isEvent()) {
            if (tmsg->isMediaAdded()) {
               emit mediaUSBEvents("media_added");
            } else if (tmsg->isMediaRemoved()) {
                emit mediaUSBEvents("media_removed");
            }
        }
    }
    message->deleteLater();
}
