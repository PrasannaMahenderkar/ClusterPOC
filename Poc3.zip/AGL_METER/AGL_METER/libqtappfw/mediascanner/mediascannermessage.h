#ifndef MEDIASCANNERMESSAGE_H
#define MEDIASCANNERMESSAGE_H

#include "message.h"

class MediascannerMessage : public Message
{
    Q_OBJECT
public:
    //        bool isPlaylistEvent() { return (this->eventName() == "playlist"); };
    //        bool isMetadataEvent() { return (this->eventName() == "metadata"); };
    bool isMediaAdded() { return (this->eventName() == "media_added"); };
    bool isMediaRemoved() { return (this->eventName() == "media_removed"); };
    bool createRequest(QString verb, QJsonObject parameter);
};

#endif // MEDIASCANNERMESSAGE_H
