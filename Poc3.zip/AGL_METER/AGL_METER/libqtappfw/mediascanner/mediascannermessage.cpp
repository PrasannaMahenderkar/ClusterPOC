#include <QDebug>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

#include "mediascannermessage.h"

bool MediascannerMessage::createRequest(QString verb, QJsonObject parameter)
{
    QStringList verbs {"media_result","subscribe", "unsubscribe"};
    if (!verbs.contains(verb))
        return false;

    return Message::createRequest("mediascanner", verb, parameter);
}
