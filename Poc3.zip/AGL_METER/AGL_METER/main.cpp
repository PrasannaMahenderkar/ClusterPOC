#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QObject>
#include <QCommandLineParser>
#include <QQuickWindow>
//#include <QDebug>
#include <QQmlContext>
#include "MeterHMIHandler.h"
#include <QThread>
#include <qlibwindowmanager.h>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QString applicationName = QString("AGL_Meter");
    QCommandLineParser parser;
    parser.addPositionalArgument("port", app.translate("main", "port for binding"));
    parser.addPositionalArgument("secret", app.translate("main", "secret for binding"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.process(app);
    QStringList positionalArguments = parser.positionalArguments();

    int port = 1058;
    QString token = "HELLO";

    if (positionalArguments.length() == 2) {
        port = positionalArguments.takeFirst().toInt();
        token = positionalArguments.takeFirst();
    }

    QLibWindowmanager* layoutHandler = new QLibWindowmanager();
    if(layoutHandler->init(port,token) != 0){
        exit(EXIT_FAILURE);
    }

    if (layoutHandler->requestSurface(applicationName) != 0) {
        exit(EXIT_FAILURE);
    }

    layoutHandler->set_event_handler(QLibWindowmanager::Event_SyncDraw, [layoutHandler, applicationName](json_object *object) {
        layoutHandler->endDraw(applicationName);
    });

    QThread::sleep(1);

    QQmlApplicationEngine engine;

    MeterHMIHandler *meterHMIHandlerObj = new MeterHMIHandler(nullptr, engine.rootContext(),port,token);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    QObject *root = engine.rootObjects().first();
    QQuickWindow *window = qobject_cast<QQuickWindow *>(root);
    QObject::connect(window, SIGNAL(frameSwapped()), layoutHandler, SLOT(slotActivateSurface()));

    int output = app.exec();

    delete meterHMIHandlerObj;

    return output;
}
