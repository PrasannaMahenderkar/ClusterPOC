#!/bin/sh
echo "---Enter the USB Port of CANUSB (e.g./dev/ttyUSB0)---"
read port
echo "---Starting CANUSB at 500 Kbps on slcan0---" 
sudo slcand -o -c -f -s6 $port slcan0
sleep 1
sudo ifconfig slcan0 up
