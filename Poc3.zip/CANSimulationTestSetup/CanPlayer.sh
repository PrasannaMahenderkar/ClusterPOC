#!/bin/sh
while true
do
canplayer -I CANLOG_sample.log slcan0=can0
sleep 180 #logfile runs for 3minutes
done