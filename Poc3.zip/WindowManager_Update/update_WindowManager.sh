#!/bin/bash

echo "Updating window manager..."

# get script directory path
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# move to script directory
cd $DIR

# take backup of old window manager
backup_dir=/home/WM_Backup
mkdir $backup_dir
cp -r /var/local/lib/afm/applications/windowmanager-service-2017/0.1/etc $backup_dir/
cp -r /var/local/lib/afm/applications/windowmanager-service-2017/0.1/lib $backup_dir/

# remove directories affer backup
rm -rf /var/local/lib/afm/applications/windowmanager-service-2017/0.1/etc
rm -rf /var/local/lib/afm/applications/windowmanager-service-2017/0.1/lib

# update with new folders
cp -r etc /var/local/lib/afm/applications/windowmanager-service-2017/0.1/
cp -r lib /var/local/lib/afm/applications/windowmanager-service-2017/0.1/

echo "window manager updated successfully. Rebooting...."
sleep 1

# finally reboot the system
reboot
